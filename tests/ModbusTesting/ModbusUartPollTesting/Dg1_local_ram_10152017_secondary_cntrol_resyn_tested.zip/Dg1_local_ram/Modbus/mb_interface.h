/*
 * mb_interface.h
 */

#ifndef MB_INTERFACE_H_
#define MB_INTERFACE_H_



extern void ModbusInit(void);
extern void ModbusPoll(void);

#endif /* MB_INTERFACE_H_ */
